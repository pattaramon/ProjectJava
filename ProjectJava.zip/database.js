module.exports={
    db:'mongodb+srv://Pattaramon:meiji517@cluster0.w6vdv.mongodb.net/project_js?retryWrites=true&w=majority'
}